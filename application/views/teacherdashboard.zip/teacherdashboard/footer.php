 <!-- start footer -->
        <div class="page-footer">
            <div class="page-footer-inner"> 2018 &copy; Skyevo developed By
            <a href="mailto:redstartheme@gmail.com" target="_top" class="makerCss">Deepak Maurya</a>
            </div>
            <div class="scroll-to-top">
                <i class="material-icons">eject</i>
            </div>
            <div class="scroll-to-top" style="display: block;">
                <i class="material-icons">eject</i>
            </div>
        </div>
        <!-- end footer -->
    </div>
    <!-- start js include path -->
    <script src="<?php echo base_url(); ?>assetes/adminuser/assets/plugins/jquery/jquery.min.js" ></script>
	<script src="<?php echo base_url(); ?>assetes/adminuser/assets/plugins/popper/popper.min.js" ></script>
    <script src="<?php echo base_url(); ?>assetes/adminuser/assets/plugins/jquery-blockui/jquery.blockui.min.js" ></script>
	<script src="<?php echo base_url(); ?>assetes/adminuser/assets/plugins/jquery-slimscroll/jquery.slimscroll.js"></script>
    <!-- bootstrap -->
    <script src="<?php echo base_url(); ?>assetes/adminuser/assets/plugins/bootstrap/js/bootstrap.min.js" ></script>
    <!-- counterup -->
    <script src="<?php echo base_url(); ?>assetes/adminuser/assets/plugins/counterup/jquery.waypoints.min.js" ></script>
    <script src="<?php echo base_url(); ?>assetes/adminuser/assets/plugins/counterup/jquery.counterup.min.js" ></script>
    <!-- Common js-->
	<script src="<?php echo base_url(); ?>assetes/adminuser/assets/js/app.js" ></script>
    <script src="<?php echo base_url(); ?>assetes/adminuser/assets/js/layout.js" ></script>
    <script src="<?php echo base_url(); ?>assetes/adminuser/assets/js/theme-color.js" ></script>
    <!-- material -->
    <script src="<?php echo base_url(); ?>assetes/adminuser/assets/plugins/material/material.min.js"></script>
    <!-- morris chart -->
    <script src="<?php echo base_url(); ?>assetes/adminuser/assets/plugins/morris/morris.min.js" ></script>
    <script src="<?php echo base_url(); ?>assetes/adminuser/assets/plugins/morris/raphael-min.js" ></script>
    <script src="<?php echo base_url(); ?>assetes/adminuser/assets/js/pages/chart/morris/morris-home-data.js" ></script>

     <!-- data tables -->
    <script src="<?php echo base_url(); ?>assetes/adminuser/assets/plugins/datatables/jquery.dataTables.min.js" ></script>
    <script src="<?php echo base_url(); ?>assetes/adminuser/assets/plugins/datatables/plugins/bootstrap/dataTables.bootstrap4.min.js" ></script>
    <script src="<?php echo base_url(); ?>assetes/adminuser/assets/js/pages/table/table_data.js" ></script>
    <!-- end js include path -->
  </body>
</html>